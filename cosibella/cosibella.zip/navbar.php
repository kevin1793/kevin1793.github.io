<div class="back_up" onclick="backTop();">

</div>
<div class="nav_cont">
    <div class="navbar1">

    </div>
    <div class="navbar2">
        <div class="nav_items">
            <a href="main.html">
                <span  class="nav_item">
                    Home
                </span>
            </a>
            <a href="nails.html">
                <span class="nav_item">
                    Nails
                </span>
            </a>
            <a href="spa.html">
                <span class="nav_item">
                    Spa
                </span>
            </a>
            <a href="about-us.html">
                <span class="nav_item">
                    About Us
                </span>
            </a>
            <a href="gift-cards.html">
                <span class="nav_item">
                    Gift Cards
                </span>
            </a>
            <a href="contact-us.html">
                <span class="nav_item">
                    Contact Us
                </span>
            </a>
        </div>
    </div>
    <div class="navbar3">
        <!-- <p>Call Us (568) 247 6700</p> -->
    </div>
</div>